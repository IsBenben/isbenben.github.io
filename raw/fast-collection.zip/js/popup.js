(async function () {
  'use strict';

  const storage = new Proxy(
    {},
    {
      get: function (target, prop) {
        return new Promise((resolve, reject) => {
          chrome.storage.sync.get(prop, function (result) {
            resolve(result[prop]);
          });
        });
      },
      set: function (target, prop, value) {
        return new Promise((resolve, reject) => {
          chrome.storage.sync.set({ [prop]: value }, function () {
            resolve(value);
          });
        });
      },
    }
  );

  let sameMeaningValue = await storage.sameMeaning;
  const sameMeaningList = document.getElementById('same-meaning-list');
  function updateSameMeaningList() {
    if (!sameMeaningValue.length) {
      sameMeaningList.innerHTML = '<li><em>No same meaning words</em></li>';
      return;
    }
    sameMeaningList.innerHTML = sameMeaningValue
      .map((value) => `<li>${value}<button>X</button></li>`)
      .join('');
    for (const button of sameMeaningList.querySelectorAll('button')) {
      button.addEventListener('click', () => {
        const index = [...sameMeaningList.children].indexOf(
          button.parentElement
        );
        sameMeaningValue.splice(index, 1);
        storage.sameMeaning = sameMeaningValue;
        updateSameMeaningList();
      });
    }
  }
  if (!Array.isArray(sameMeaningValue)) {
    sameMeaningValue = [];
  }
  updateSameMeaningList();
  const sameMeaningInput = document.getElementById('same-meaning-input');
  const sameMeaningButton = document.getElementById('same-meaning-button');
  sameMeaningButton.addEventListener('click', () => {
    sameMeaningValue.push(sameMeaningInput.value);
    storage.sameMeaning = sameMeaningValue;
    updateSameMeaningList();
    sameMeaningInput.value = '';
    sameMeaningInput.focus();
  });
})();
