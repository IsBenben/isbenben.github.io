setTimeout(function () {
  'use strict';

  function delay(ms = 20) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function matchedPart(full, part) {
    if (!full.startsWith(part)) {
      return;
    }
    const rest = full.substring(part.length).trim();
    if (/^\d+$/.test(rest)) {
      return +rest;
    }
    return;
  }

  const storage = new Proxy(
    {},
    {
      get: function (target, prop) {
        return new Promise((resolve, reject) => {
          chrome.storage.sync.get(prop, function (result) {
            resolve(result[prop]);
          });
        });
      },
      set: function (target, prop, value) {
        return new Promise((resolve, reject) => {
          chrome.storage.sync.set({ [prop]: value }, function () {
            resolve(value);
          });
        });
      },
    }
  );

  const ob = new MutationObserver(async function (mutations) {
    for (const mutation of mutations) {
      const [node] = mutation.addedNodes;
      if (
        !node ||
        node.nodeType !== Node.ELEMENT_NODE ||
        !node.classList.contains('bili-dialog-m')
      ) {
        continue;
      }
      const container = node.querySelector('.collection-m-exp');
      if (!container) {
        continue;
      }

      const buttonsContainer = container.querySelector(
        '.group-list .add-group'
      );
      async function addGroup(name) {
        const addButton = buttonsContainer.querySelector('.add-btn');
        if (!addButton) {
          return;
        }
        addButton.click();
        await delay();
        const input = buttonsContainer.querySelector('input');
        if (!input) {
          return;
        }
        input.value = name;
        input.dispatchEvent(new Event('input'));
        await delay();
        const submitButton = buttonsContainer.querySelector('.submit');
        if (!submitButton) {
          return;
        }
        submitButton.click();
        while (buttonsContainer.querySelector('.submit')) {
          await delay();
        }
        await delay();
      }
      const autoGroupButton = document.createElement('div');
      autoGroupButton.classList.add('add-btn');
      autoGroupButton.innerText = '自动分类收藏夹';
      autoGroupButton.addEventListener('click', async () => {
        let sameMeaningValue = await storage.sameMeaning;
        if (!Array.isArray(sameMeaningValue)) {
          sameMeaningValue = [];
        }

        const tags = document.querySelectorAll(
          '.tag-panel .tag .ordinary-tag a'
        );
        const tagNames = [...tags].map((tag) => {
          let result = tag.innerText;
          for (const sameMeaning of sameMeaningValue) {
            if (sameMeaning.split(',').includes(result)) {
              result = sameMeaning.split(',')[0];
              break;
            }
          }
          return result;
        });
        for (const tagName of tagNames) {
          await setGroup(tagName);
        }
      });
      buttonsContainer.appendChild(autoGroupButton);

      const groupsContainer = container.querySelector('.group-list ul');
      if (!groupsContainer) {
        continue;
      }
      async function setGroup(target) {
        const groups = groupsContainer.querySelectorAll('li');
        let id = 1;
        for (const group of groups) {
          const name = group.querySelector('.fav-title').innerText;
          if (name === '默认收藏夹') {
            continue;
          }
          const matched = matchedPart(name, target);
          if (matched === undefined) {
            continue;
          }
          const checkbox = group.querySelector('input[type="checkbox"]');
          if (checkbox.checked) {
            return;
          }
          const count = +group.querySelector('.count').innerText.split('/')[0];
          if (count < 1000) {
            checkbox.checked = true;
            checkbox.dispatchEvent(new Event('change'));
            await delay();
            return;
          }
          if (matched >= id) {
            id = matched + 1;
          }
        }
        await addGroup(target + ' ' + id);
      }
    }
  });

  const body = document.querySelector('body');
  ob.observe(body, {
    childList: true,
  });
}, 1000);
